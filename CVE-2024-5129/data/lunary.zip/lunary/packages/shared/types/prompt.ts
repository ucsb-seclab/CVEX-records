export type TemplateVariables = Record<string, string>
