import runRadarJob from "./jobs/radar"

runRadarJob()
