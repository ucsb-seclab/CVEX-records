/*
 * ["AND", { id: 'tag', paramsData: { tag: 'foo' } }, { id: 'tag', paramsData: { tag: 'bar' } }, ["OR", { id: 'tag', paramsData: { tag: 'baz' } }, { id: 'tag', paramsData: { tag: 'qux' } }]
 */
