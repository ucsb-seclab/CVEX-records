import * as Sentry from "@sentry/nextjs"

Sentry.init({
  dsn: "https://39824297fdaaaa06ab62a4d077cdfc8b@o4506599397588992.ingest.us.sentry.io/4506599400407040",
  tracesSampleRate: 1.0,
})
