export const SEAT_ALLOWANCE = {
  free: 1,
  pro: 4,
  unlimited: 10,
  custom: 100,
}

export const EVENTS_ALLOWANCE = {
  free: 1000,
  pro: 4000,
  unlimited: 100000,
  custom: 1000000,
}
