<?php return array('dependencies' => array('lodash', 'moment', 'wp-i18n'), 'version' => '74eba1e596e5ac42e7a6');
