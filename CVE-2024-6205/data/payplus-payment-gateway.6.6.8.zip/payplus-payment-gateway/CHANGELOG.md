# Changelog

All notable changes to this project will be documented in this file.

##  [6.6.8] - 2024-05-03 - (Eggman)

### Changes 

* Add    - Display PayPlus Invoice+ charges and refunds in a dedicated metabox in the order page.
* Add    - Option to hide the Invoice+ links in the order notes in Invoice+ settings.
* Add    - Display PayPlus Invoice+ docs without activation of Invoice+.
* Add    - Display PayPlus Invoice+ refunds and invoices in all orders page via show/hide list arrow button. 
* Fix    - Fire Completed is fired only if not default-woo is selected and not together.
* Add    - Hide Delete/Update custom fields - with option in the settings to be cancelled - default is yes.
* Tweak  - Location of plugin credit (bottom of the page in plugin settings).
* Tweak  - Hide PayPlus loader if "Make Payment" fails because amount is larger than allowed.
* Change - Disable express checkout functions run if not enabled.
* Fix    - Check if product variable is a valid product object in express checkout function.
* Add    - Prepare plugin support for Secure3d - with saved cards only.
* Fix    - Bit payments redirection after successful order purchase from uPay on mobile phones.
* Tweak  - Database version update - refactored options check and settings to run only when needed.



##  [6.6.7] - 2024-05-29 - (Knuckles)

### Changes

* Tweak - Multiple refunds can now be done in an automatic way as well as manual.
* Tweak - Some hebrew translations were fixed.
* Tweak - Added description to fire completed configuration option.
* Tweak - Added error message when an error occurs on "Make Payment" in admin orders edit.
* Fix   - "Make Payment" button for J5 payment now allows admin to charge up until original J5 charge. 
* Fix   - Removed short code usage with payplus error page.

##  [6.6.5] - 2024-05-26 - (Tails)

### Changes

* Tweak - New apple developer merchantid domain association file.
* Tweak - Show 0 priced products in invoices.
* Tweak - "Get PayPlus Data" button now adds all payplus meta fields to the order meta.
* Fix   - Invoices created with "Get PayPlus Data" button will have correct payment method data.

##  [6.6.4] - 2024-05-26 - (Sonic)

### Changes

* Fix - Bug preventing save users in admin.
* Fix - Show correct SKU when invoice with more than one variation product exist.
* Add - Mark in red - When Invoice+ is enabled shows the user which fields must be set.

## [6.6.3] - 2024-05-19 - (The New Way)

### Changes

* Add   - Check/Get order - ipn data from payplus in Admin orders via button click.
* Add   - "Website code" - Added to Invoice+: Add a unique string for each website if you have more than one website connected to our gateway.
* Add   - Save credit card checkbox in new WooCommerce Checkout Blocks.
* Tweak - Refactor for meta data to use High Performance Order Storage - HPOS with support for stores without - will be supported for traditional post meta records - for existing orders and stores that have no current support for HPOS.
* Add   - Legacy post meta support checkbox - Default is checked - In future releases this will be unchecked. (Plugin users that have been using our gateway up until now will be able to view all data that was stored in the post meta fields) - for more information regarding HPOS go to: https://woocommerce.com/document/high-performance-order-storage/
* Add   - Invoice check and update to admin on creation - If an invoice has already been created and for some reason it has not been updated to the admin orders panel, it's link will appear and it's data will be shown without duplicate creation.
* Add   - Notice for customer when they update their billing address. (Regarding saved tokens)
* Fix - Create invoice in a non-automatic management interface in different amount than the original order.
* Fix - Save credit cards tokens - during checkout. (Supported on both classic and new checkout blocks).
* Fix - Payments with saved tokens now work on all checkout pages (Redirect, Iframe, Iframe on the same page, Iframe in a pop-up).
* Fix - Save credit card tokens - no duplicates.
* Fix - Removed log warnings for non-existing keys.
* Fix - Save credit card token with brand name. (works only with newly saved card tokens from now on)
* Fix - Correct display information on invoice for card on invoice creation with token payment.
* Fix - Display correct currency on automatic invoice creation.
* Fix - Add/Save Payment methods through "My account -> Payment methods" now saves the token with customer default billing and will work on checkout (When billing information is the same).
* Fix -J5 Invoice creation from admin with partial amount paid - fixed.

## [6.6.2] - 2024-02-01

### Changes

* Add - Support for the new WooCommerce Checkout Blocks.
